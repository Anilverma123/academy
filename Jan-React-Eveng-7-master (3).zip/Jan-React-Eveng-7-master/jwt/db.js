var mongoose = require('mongoose');
mongoose.connect(`mongodb+srv://dev:mongo123@cluster0.f8vmc.mongodb.net/nareshit?retryWrites=true&w=majority`)